import type { BBox } from '../../types/ParsedSection'

type GraphValueProps = {
  value: string
  bbox: BBox
  scale?: number
  onClick?: () => void
}

const GraphValue = ({ value, bbox, scale = 1, onClick }: GraphValueProps) => (
  <div
    style={{
      position: 'absolute',
      left: bbox.l * scale,
      top: (1000 - bbox.t) * scale,
      width: (bbox.r - bbox.l) * scale,
      height: (bbox.t - bbox.b) * scale,
      fontSize: '10px',
      color: '#222',
      backgroundColor: 'rgba(0,0,0,0.05)',
      cursor: 'pointer',
      lineHeight: 1,
    }}
    onClick={onClick}
  >
    {value}
  </div>
)

export default GraphValue