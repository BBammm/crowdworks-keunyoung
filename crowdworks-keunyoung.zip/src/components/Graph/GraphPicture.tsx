import { CSSProperties } from 'react'
import type { BBox } from '../../types/ParsedSection'

type GraphPictureProps = {
  picture: {
    self_ref: string
    page_no: number
    bbox: BBox
    children: { $ref: string }[]
  }
  textsMap: Map<string, any>
  onPointClick?: (text: string, bbox: BBox) => void
}

const scale = 1 / 1.5 // PDF 뷰어 기준 스케일 (조절 가능)

function getStyleFromBBox(bbox: BBox): CSSProperties {
  return {
    position: 'absolute',
    left: bbox.l * scale,
    top: (1000 - bbox.t) * scale,
    width: (bbox.r - bbox.l) * scale,
    height: (bbox.t - bbox.b) * scale,
    fontSize: '10px',
    lineHeight: 1,
    color: 'blue',
    backgroundColor: 'rgba(255,255,0,0.2)',
    cursor: 'pointer',
  }
}

const GraphPicture = ({ picture, textsMap, onPointClick }: GraphPictureProps) => {
  return (
    <div
      className="relative border border-gray-300 my-2"
      style={{
        width: (picture.bbox.r - picture.bbox.l) * scale,
        height: (picture.bbox.t - picture.bbox.b) * scale,
        backgroundColor: '#f9f9f9',
      }}
    >
      {picture.children.map((childRef) => {
        const textData = textsMap.get(childRef.$ref)
        if (!textData?.prov?.[0]?.bbox || !textData?.text) return null

        const bbox = textData.prov[0].bbox as BBox

        return (
          <div
            key={childRef.$ref}
            style={getStyleFromBBox(bbox)}
            onClick={() => onPointClick?.(textData.text, bbox)}
          >
            {textData.text}
          </div>
        )
      })}
    </div>
  )
}

export default GraphPicture