type GraphLabelProps = {
  text: string
  x: number
  y: number
  scale?: number
}

const GraphLabel = ({ text, x, y, scale = 1 }: GraphLabelProps) => (
  <div
    style={{
      position: 'absolute',
      left: x * scale,
      top: y * scale,
      fontSize: '10px',
      color: '#444',
    }}
  >
    {text}
  </div>
)

export default GraphLabel