import { useEffect, useState } from 'react'
import GraphPicture from './GraphPicture'
import jsonData from '../../assets/data/1.report.json'

const GraphPictureContainer = () => {
  const [pictures, setPictures] = useState<any[]>([])
  const [textsMap, setTextsMap] = useState<Map<string, any>>(new Map())

  useEffect(() => {
    const raw = jsonData as any

    // pictures
    const pics = raw.pictures || []
    setPictures(pics)

    // textsMap
    const map = new Map<string, any>()
    ;(raw.texts || []).forEach((t: any) => map.set(t.self_ref, t))
    setTextsMap(map)
  }, [])

  return (
    <div className="space-y-4">
      {pictures.map((pic) => (
        <GraphPicture
          key={pic.self_ref}
          picture={pic}
          textsMap={textsMap}
          onPointClick={(text, bbox) => {
            console.log('clicked', text, bbox)
          }}
        />
      ))}
    </div>
  )
}

export default GraphPictureContainer