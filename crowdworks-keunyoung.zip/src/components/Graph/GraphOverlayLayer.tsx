import GraphPicture from './GraphPicture'

type Props = {
  pictures: any[]
  textsMap: Map<string, any>
  onPointClick: (text: string, bbox: any) => void
}

const GraphOverlayLayer = ({ pictures, textsMap, onPointClick }: Props) => {
  return (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
      {pictures.map((pic) => (
        <GraphPicture
          key={pic.self_ref}
          picture={pic}
          textsMap={textsMap}
          onPointClick={onPointClick}
        />
      ))}
    </div>
  )
}

export default GraphOverlayLayer