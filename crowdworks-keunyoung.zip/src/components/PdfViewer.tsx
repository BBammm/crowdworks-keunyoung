import { useEffect, useRef, useState } from 'react'
import { Document, Page } from 'react-pdf'
import type { BBox } from '../types/ParsedSection'
import GraphOverlayLayer from './Graph/GraphOverlayLayer'

type Props = {
  pdfUrl: string
  graphPictures: any[]
  textsMap: Map<string, any>
  highlight?: { text: string; bbox: BBox } | null
}

const PdfViewer = ({ pdfUrl, graphPictures, textsMap, highlight }: Props) => {
  const containerRef = useRef<HTMLDivElement>(null)

  return (
    <div ref={containerRef} className="relative">
      <Document file={pdfUrl}>
        <Page pageNumber={1} width={800} />
      </Document>

      {/* ✅ 그래프 UI 오버레이 */}
      <GraphOverlayLayer
        pictures={graphPictures}
        textsMap={textsMap}
        onPointClick={(text: any, bbox: any) => {
          console.log('Graph point clicked:', text)
        }}
      />

      {/* ✅ 선택된 하이라이트 박스 (선택 시) */}
      {highlight && (
        <div
          className="absolute border-2 border-yellow-500"
          style={{
            left: highlight.bbox.l,
            top: highlight.bbox.t,
            width: highlight.bbox.r - highlight.bbox.l,
            height: highlight.bbox.t - highlight.bbox.b,
          }}
        />
      )}
    </div>
  )
}

export default PdfViewer